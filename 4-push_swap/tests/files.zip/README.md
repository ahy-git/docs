# push_swap — suíte de testes

Scripts de teste e edge cases para o projeto **push_swap** (42).
Não dependem da sua implementação: testam o binário `./push_swap`
(e, opcionalmente, `./checker`).

## Como usar

Coloque a pasta `testscripts/` na raiz do projeto (ao lado do `push_swap`
já compilado) e rode:

```sh
bash testscripts/run_all.sh            # roda a suite completa

# individuais
bash testscripts/test_errors.sh        # parsing / erros (edge cases)
bash testscripts/test_basic.sh         # uso normal + formato de saida
bash testscripts/test_correctness.sh   # corretude da ordenacao
bash testscripts/test_flags.sh         # flags e --bench
bash testscripts/compare_algos.sh      # 4 algoritmos lado a lado
bash testscripts/test_performance.sh   # contagem de ops vs limites
bash testscripts/test_stability.sh     # stress: grandes, loops, crashes
bash testscripts/test_leaks.sh         # valgrind
bash testscripts/test_norminette.sh    # norm
bash testscripts/gen_plot.sh           # gera grafico de operacoes
```

## Variáveis de ambiente

| Variável   | Padrão                 | Para quê                                  |
|------------|------------------------|-------------------------------------------|
| `PS_BIN`   | `./push_swap`          | caminho do binário push_swap              |
| `CHK_BIN`  | `./checker`            | caminho do seu checker (bonus)            |
| `CHECKER`  | (vazio)                | checker externo, ex.: `./checker_linux`   |
| `VERIFIER` | `python3 ps_verify.py` | validador interno usado por padrão        |

Exemplos:

```sh
CHECKER=./checker_linux bash testscripts/test_correctness.sh
PS_BIN=./push_swap bash testscripts/test_performance.sh 200
```

## Como a corretude é checada

Por padrão usa `ps_verify.py`, um verificador próprio que **simula** as
operações (sa/sb/ss/pa/pb/ra/rb/rr/rra/rrb/rrr) na stack e confirma se `a`
ficou ordenada e `b` vazia. Assim a suíte funciona mesmo sem o
`checker_linux`. Para usar um checker real, defina `CHECKER`.

## O que cada arquivo cobre

### Testes (pass/fail)

- **test_errors.sh** — não-numéricos, sinais malformados (`+-5`, `1-2`, `5-`,
  `--`), overflow (INT_MAX+1, INT_MIN-1, gigantes), duplicados, e casos
  EMPTY (sem args, 1 número). Casos de política ambígua (string vazia,
  `+5`, `-0`, `007`) são só **reportados**, não reprovam.
- **test_basic.sh** — uso normal: entrada já ordenada gera 0 ops; entradas
  comuns ordenam; **formato de saída** (só operações válidas, uma por linha,
  separadas por `\n`, sem espaços/tabs, newline final); args separados ==
  string única.
- **test_correctness.sh** — triviais, todas as 6 permutações de 3, casos de
  4/5, entrada como string única, e N rodadas aleatórias.
- **test_flags.sh** — cada seletor (`--simple/--medium/--complex/--adaptive`)
  ordena certo; default == adaptive; `--bench` manda métricas só pro stderr;
  flag inválida vira `Error`.
- **test_performance.sh** — roda muitas amostras de 100 e 500 números e
  compara o **pior caso** com os limites do subject (100: <2000/1500/700;
  500: <12000/8000/5500); checa também 3 (<=3 ops) e 5 (<=12 ops).
- **test_stability.sh** — stress com entradas grandes (default 500): detecta
  **crash** (sinal), **loop infinito** (timeout), ordenação errada, e
  **determinismo** (mesma entrada -> mesma saída). Testa também invertido e
  já ordenado em escala.
- **test_leaks.sh** — valgrind em caminhos válidos **e de erro** (o parser
  tem que liberar tudo antes de sair).
- **test_norminette.sh** — norm em todos `.c`/`.h`.

### Comparação e gráficos (relatório)

- **compare_algos.sh** — roda os 4 algoritmos no **mesmo input** e mostra a
  contagem de ops lado a lado, em 4 perfis de desordem (sorted, nearly,
  random, reverse). Mostra qual estratégia o `--adaptive` escolheu (via
  `--bench`) e verifica que todos ordenam.
- **gen_plot.sh** — coleta ops em vários tamanhos e gera:
  - `ps_perf.csv` (size,min,avg,max),
  - gráfico **ASCII** no terminal (sempre),
  - `ps_perf.png` (se `matplotlib` estiver instalado), com as linhas de
    referência dos limites do subject.
  Uso: `bash testscripts/gen_plot.sh [iters] [tamanhos...]`
  (ex.: `gen_plot.sh 20 5 50 100 300 500 1000`).

## Arquivos auxiliares

- `lib.sh` — config, cores e helpers compartilhados.
- `ps_verify.py` — verificador interno (simulador das stacks).
- `stats.py` / `agg.py` — estatísticas das contagens de operações.
- `plot.py` — renderiza o gráfico (ASCII + PNG).

## Observações

- No macOS troque valgrind por `leaks --atExit -- ./push_swap ...`.
- Os `[FAIL]` de performance e de 3/5 números só passam com um algoritmo
  otimizado (ex.: radix). Um sort O(n²) ingênuo reprova de propósito.
- Sem `matplotlib`? O `gen_plot.sh` ainda gera CSV + gráfico ASCII.
