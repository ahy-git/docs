#!/usr/bin/env python3
# agg.py - read integers from stdin, print "size,min,avg,max" for argv[1].
import sys

size = sys.argv[1]
vals = [int(x) for x in sys.stdin.read().split()]
if not vals:
    print(f"{size},0,0,0")
    sys.exit(0)
mn = min(vals)
mx = max(vals)
avg = sum(vals) / len(vals)
print(f"{size},{mn},{avg:.1f},{mx}")
