#!/usr/bin/env bash
# gen_plot.sh - collect operation counts across input sizes and plot them.
#
# Produces:
#   - ps_perf.csv  (size,min,avg,max)
#   - ASCII chart on screen
#   - ps_perf.png  (if matplotlib is installed)
#
# Usage: ./gen_plot.sh [iters_per_size] [sizes...]
#   default iters = 10, default sizes = 5 50 100 200 300 500

. "$(dirname "$0")/lib.sh"
need_ps_bin

ITERS="${1:-10}"
shift 2>/dev/null
SIZES=("$@")
if [ "${#SIZES[@]}" -eq 0 ]; then
	SIZES=(5 50 100 200 300 500)
fi

CSV="ps_perf.csv"
PNG="ps_perf.png"

title "Coletando dados ($ITERS rodadas por tamanho)"
printf "size,min,avg,max\n" > "$CSV"

for size in "${SIZES[@]}"; do
	results=()
	i=0
	while [ "$i" -lt "$ITERS" ]; do
		nums="$(rand_nums "$size")"
		# shellcheck disable=SC2086
		ops="$("$PS_BIN" $nums 2>/dev/null | grep -c .)"
		results+=("$ops")
		i=$((i + 1))
	done
	line="$(printf "%s\n" "${results[@]}" | python3 "$SCRIPT_DIR/agg.py" "$size")"
	printf "%s\n" "$line" >> "$CSV"
	info "n=$size -> $line"
done

title "Grafico"
python3 "$SCRIPT_DIR/plot.py" "$CSV" "$PNG"

printf "\nCSV: %s\n" "$CSV"
