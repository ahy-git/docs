#!/usr/bin/env python3
# plot.py - render a push_swap operation-count chart.
#
# Reads CSV lines "size,min,avg,max" from a file (argv[1]) or stdin.
# Always prints an ASCII chart. Saves a PNG (argv[2]) if matplotlib exists.
#
# Usage: python3 plot.py data.csv [out.png]

import sys


def read_rows(path):
    rows = []
    if path and path != "-":
        with open(path) as f:
            text = f.read()
    else:
        text = sys.stdin.read()
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.lower().startswith("size"):
            continue
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 4:
            size = int(parts[0])
            mn, avg, mx = float(parts[1]), float(parts[2]), float(parts[3])
            rows.append((size, mn, avg, mx))
    return rows


def ascii_chart(rows):
    if not rows:
        print("  (sem dados)")
        return
    top = max(r[3] for r in rows) or 1
    width = 50
    print()
    print("  Operacoes por tamanho de entrada (barra = avg, | = max)")
    print("  " + "-" * (width + 22))
    for size, mn, avg, mx in rows:
        bar_len = int(avg / top * width)
        mark = int(mx / top * width)
        bar = list("." * width)
        for i in range(min(bar_len, width)):
            bar[i] = "#"
        if 0 <= mark < width:
            bar[mark] = "|"
        line = "".join(bar)
        print(f"  n={size:<5d} avg={avg:>8.0f} max={mx:>8.0f} {line}")
    print("  " + "-" * (width + 22))


def save_png(rows, out):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        print(f"  (matplotlib ausente: PNG nao gerado, use o CSV)")
        return False
    sizes = [r[0] for r in rows]
    mins = [r[1] for r in rows]
    avgs = [r[2] for r in rows]
    maxs = [r[3] for r in rows]
    fig, ax = plt.subplots(figsize=(9, 5.5))
    ax.plot(sizes, avgs, "o-", label="media", color="#2b6cb0")
    ax.fill_between(sizes, mins, maxs, alpha=0.18, color="#2b6cb0",
                    label="min-max")
    # subject reference thresholds
    for n, lim, txt in [(100, 2000, "100: passa"), (100, 700, "100: excel"),
                        (500, 12000, "500: passa"), (500, 5500, "500: excel")]:
        ax.scatter([n], [lim], marker="_", s=400, color="#c53030", zorder=5)
        ax.annotate(txt, (n, lim), fontsize=7, color="#c53030",
                    xytext=(4, 2), textcoords="offset points")
    ax.set_xlabel("quantidade de numeros")
    ax.set_ylabel("operacoes geradas")
    ax.set_title("push_swap - operacoes vs tamanho da entrada")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out, dpi=120)
    print(f"  PNG salvo em: {out}")
    return True


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "-"
    out = sys.argv[2] if len(sys.argv) > 2 else None
    rows = read_rows(path)
    ascii_chart(rows)
    if out:
        save_png(rows, out)


if __name__ == "__main__":
    main()
