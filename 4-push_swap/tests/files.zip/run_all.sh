#!/usr/bin/env bash
# run_all.sh - runs the full push_swap test suite.
#
# Usage: ./run_all.sh
# Env: PS_BIN, CHK_BIN, CHECKER, VERIFIER (see lib.sh)

. "$(dirname "$0")/lib.sh"
need_ps_bin

D="$(dirname "$0")"
FAILED=0

run_stage() {
	local script="$1"
	shift
	printf "\n${C_BOLD}########## %s ##########${C_RESET}\n" "$script"
	bash "$D/$script" "$@"
	[ $? -ne 0 ] && FAILED=$((FAILED + 1))
}

run_stage test_norminette.sh
run_stage test_errors.sh
run_stage test_basic.sh
run_stage test_correctness.sh 100 20
run_stage test_flags.sh 100
run_stage compare_algos.sh 100
run_stage test_performance.sh 50
run_stage test_stability.sh 500 20 10
run_stage test_leaks.sh 100

printf "\n${C_BOLD}===================================${C_RESET}\n"
if [ "$FAILED" -eq 0 ]; then
	printf "${C_GREEN}${C_BOLD}TODAS AS ETAPAS PASSARAM${C_RESET}\n"
	exit 0
else
	printf "${C_RED}${C_BOLD}%d ETAPA(S) COM FALHA${C_RESET}\n" "$FAILED"
	exit 1
fi
